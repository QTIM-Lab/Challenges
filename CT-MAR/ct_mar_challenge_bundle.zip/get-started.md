* Register to get access via the Challenge website (Link COMING SOON)
* Download the training dataset
* Study the methodology that was used to generate the training dataset
* Train or develop your MAR algorithm
* Phase 2: Download the additional data and submit your results to receive preliminary scores
* Phase 3: Download the final scoring dataset and submit your final results
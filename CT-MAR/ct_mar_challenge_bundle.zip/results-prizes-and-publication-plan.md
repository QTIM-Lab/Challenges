At the conclusion of the challenge, the following information will be provided to each participant:

* The evaluation results for the submitted cases
* The overall ranking among the participants
The top 2 participants (one member from each team only):

* Will present their algorithm and results at the AAPM Annual Meeting & Exhibition (July 21-25, 2024, Los Angeles, CA). In-person attendance is required.
* Will be awarded complimentary registration to the AAPM Annual Meeting & Exhibition.
A manuscript summarizing the challenge results will be submitted for publication following completion of the challenge.
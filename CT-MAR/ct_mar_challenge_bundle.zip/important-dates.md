* Oct 30, 2023: Phase 1 starts. Registration opens. 14,000 training cases made available to participants.
* Feb 19, 2024: Phase 2 starts. 1,000 test cases and 5 preliminary scoring cases are released. Participants can submit the 5 processed preliminary results up to twice to receive feedback on relative scoring.
* May 5, 2024: Deadline for participants to provide a one-page summary describing their final algorithm and PSNR/SSIM results on the 1,000 test cases.
* May 6, 2024: Phase 3 starts. Final scoring dataset is released.
* May 20,2024: Deadline for the final submission of results (midnight, ET)
* June 3, 2024: Winners (top 3) are announced.
* July 21-25, 2024: AAPM Annual Meeting & Exhibition: top two teams will present on their work during a dedicated challenge session.
* Fall 2024: The challenge organizers summarize the grand challenge in a journal paper. Datasets and scoring routines will be made public
###### Organizers
* Eri Haneda (Lead Organizer) (GE HealthCare Technology & Innovation Center)
* Bruno De Man (GE HealthCare Technology & Innovation Center)
* Wenjun Xia (Rensselaer Polytechnic Institute)
* Ge Wang (Rensselaer Polytechnic Institute)
* Nils Peters (Massachusetts General Hospital)
* Harald Paganetti (Massachusetts General Hospital)
* the AAPM Working Group on Grand Challenges

###### Acknowledgements
The developments leading to this grand challenge were supported by the NIH/NIBIB grant R01EB031102.

###### Contacts
For further information, please contact the lead organizer, Eri Haneda (haneda@ge.com) or AAPM staff member, Emily Townley (emily@aapm.org)